jQuery(document).ready(function($) {

    "use strict";

    // Initialize typed js
    var typed = new Typed("#banityped", {
        stringsElement: document.getElementById('typed-strings'),
        typeSpeed: 100,
        backSpeed: 50,
        loop: true
    });

});
